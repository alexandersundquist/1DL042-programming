def inbetween_a_and_b (text):
    a_list=[]
    b_list=[]
    for i in range(len(text)):
        if text[i]=="a":
            a_list.append(i)
        elif text[i]=="b":
            b_list.append(i)
    if a_list == [] or b_list == []:
        state=False
    for index in range(len(b_list)):
        for number in range(len(a_list)):
            if a_list[number]<b_list[index]:
                state=True
            else:
                state=False

    if state == True:
        first_a = a_list[0]
        following_b = 0
        while following_b == 0:
            for ind in range(len(b_list)):
                if b_list[ind]>first_a:
                    following_b=b_list[ind]
                    return text[first_a+1:following_b]
    else:
        return "does not work"
    
def testfunction():
    testfall=["arrb", "raa", "rrb", "arrarrb", "arrbrrb", "brra", "brr", "rrb", "brrbrra", "brrarra", "brrarrb", "brrarrbrra","arrbrrarrbrrarrb",""]
    for text in testfall:
        print(inbetween_a_and_b(text))

testfunction()